kailleraclient.dll by Anti3D.com

Anti3D Master Client v1.0 (09/10/2005) by Paul Cowan (Moosehead)
Kaillera v0.9 (c) 2001 Christophe Thibault

http://master.anti3d.com
http://www.anti3d.com

ABOUT 

This kailleraclient.dll is a standard Kaillera v0.9 dll that has been altered 
to use the Master Server list at www.anti3d.com instead of www.kaillera.com. 
This was done because (as of Sept 2005) the Kaillera website has been down for 
months, and as a result nobody is able to get a server list. Users wish to 
continue to use Kaillera; therefore the owner of Anti3D.com has started an 
alternative Kaillera Master Server.

Anti3D.com's Master Server is currently driven from Anti3D's TopServers list. 
Any server owner may freely Add their server to the list via the website, but 
no servers automatically update the list.

Should the original Master Server list at www.kaillera.com come back up 
sometime in the future, Anti3D.com's Master will act as a mirror so no 
confusion arrises between people with different versions of the dll.

INSTALL

Backup your existing kailleraclient.dll, which is in your emulator's home 
directory, and then unzip this file into the directory, overwriting 
kailleraclient.dll.

LICENSE

As of September 2005, the software known as Kaillera has no official website 
and the author has made no new releases or expressed any interest in 
continuing development of the software for approximately 4 years.  Therefore 
we are considering it abandonware: http://en.wikipedia.org/wiki/Abandonware 

This kailleraclient.dll is released under the same license as the original, 
assuming the original license still exists and is applicable.  Otherwise 
this software is Public Domain.

